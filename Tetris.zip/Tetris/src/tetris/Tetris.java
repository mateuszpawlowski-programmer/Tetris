/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tetris;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Tetris extends JPanel implements Runnable,KeyListener{

    public JPanel panel=new JPanel();
    public JFrame frame=new JFrame("Tetris");
    public Thread thread;
    
    public Brick brick;
    public int a=0;
    
    public static int[][] tetris=new int[20+2][10+2];
    
    public static int[][] bricks_table=new int[20+2][10+2];
    
    public int score=0;
    public int level=1;
    
    public Tetris()
    {
    
        tetris=new int[][]
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0}
        };
        
        bricks_table=new int[][]
        {
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1}
        };
        
        brick=new Brick("L");
        
        this.addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
    }
    
    public static void main(String[] args) {
    Tetris t=new Tetris();
        t.panel = t;
        t.frame = new JFrame("Tetris.");
        t.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        t.frame.getContentPane().add(t.panel);
        t.panel.setSize(300, 300);
        t.frame.setLocation(500, 300);
        t.frame.pack();
        t.frame.show();
        t.thread=new Thread(t);
        t.thread.start();
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(640, 520);
    }

    public void update_table()
    {
        
            for(int y=0;y<20+2;y++)
                {
                    for(int x=0;x<10+2;x++)
                    {
                        if(bricks_table[y][x]==1) tetris[y][x]=bricks_table[y][x];
                    }
                }
        
    }
    
    public void clear_table()
    {
        
            for(int y=0;y<20;y++)
            {
                boolean row_complete=true;
                
                for(int x=0;x<10;x++){
                    if(Tetris.bricks_table[y][x]==0) row_complete=false;
                }
                if(y>0 && row_complete==true)
                {
                 move_bricks(y);
                 score=score+10;
                 check_score();
                 score=score+10;
                 
                }
            }
    }
    
    public void check_score()
    {
        if(score>=0&&score<=100) level=1;
        if(score>100&&score<=200) level=2;
        if(score>200&&score<=300) level=3;
        if(score>300&&score<=400) level=4;
        if(score>500&&score<=600) level=5;
        if(score>600&&score<=700) level=6;
        if(score>700&&score<=800) level=7;
        if(score>800&&score<=900) level=8;
        if(score>900&&score<=1000) level=9;
        if(score>1000&&score<=1100) level=10;
    }
    
    public void move_bricks(int to_y)
    {
        for(int y=to_y-1;y>0;y--)
        {
            for(int x=0;x<10;x++)
            {
            Tetris.bricks_table[y+1][x]=0;
            Tetris.bricks_table[y+1][x]=Tetris.bricks_table[y][x];
            }
        }
    }
    
    public void paintComponent(Graphics g){
    	super.paintComponent(g);
        g.setColor(Color.white);
        g.setColor(new Color(255,255,255));
        g.fillRect(0, 0, 640, 520);
        
        
        tetris=new int[][]
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0}
        };
        
        brick.getBrick();
        
        int posx=brick.x;
        int posy=brick.y;
        
        for(int y=0;y<4;y++)
        {
            
        for(int x=0;x<4;x++)
        {
            //tetris[y][x]=1;
            if(brick.brick_table[y][x]==1){
            tetris[posy+y][posx+x]=brick.brick_table[y][x];
            }
        }
        }
        
        update_table();
        clear_table();
        
        
        
        //draw tetris
        for(int y=0;y<20;y++)
        {
            for(int x=0;x<10;x++)
            {
                g.setColor(new Color(0,80,0));
                g.drawRect(x*20,y*20,20,20);
                if(tetris[y][x]==1)
                {
                    g.setColor(new Color(0,180,0));
                    g.fillRect(x*20, y*20, 20, 20);
                }
            }
        }
        g.setColor(new Color(0,80,0));
        g.drawString("Level:"+level, 300, 25);
        g.drawString("Score:"+score, 300, 50);
        
                String next_brick="";
                if(brick.next==0) {next_brick="L"; drawNext(new Brick("L"),g);}
                if(brick.next==1) {next_brick="RL";drawNext(new Brick("RL"),g);}
                if(brick.next==2) {next_brick="S";drawNext(new Brick("S"),g);}
                if(brick.next==3) {next_brick="RS";drawNext(new Brick("RS"),g);}
                if(brick.next==4) {next_brick="T";drawNext(new Brick("T"),g);}
                if(brick.next==5) {next_brick="I";drawNext(new Brick("I"),g);}
                if(brick.next==6) {next_brick="B";drawNext(new Brick("B"),g);}
                
                g.drawString("Next:", 300, 75);
    }
    
    public void drawNext(Brick next_brick,Graphics g)
    {
        next_brick.getBrick();
        
        int to_y=3;
        
        if(next_brick.brick_type.equals("I")) to_y=4;
        
        for(int y=0;y<to_y;y++){
            for(int x=0;x<to_y;x++)
            {
            g.setColor(new Color(0,80,0));
            g.drawRect(x*20+300, y*20+80, 20, 20);
            
                if(next_brick.brick_table[y][x]==1)
                {
                    g.setColor(new Color(0,180,0));
                    g.fillRect(x*20+300, y*20+80, 20, 20);
                    g.setColor(new Color(0,80,0));
                };
            }
        }
    }
    
    public void rotate()
    {
        if(brick.check_collision_rotate()==false)
        {
            brick.rot=brick.rot+1;
            if(brick.rot==5) brick.rot=1;
        }
    }
    
    public void down()
    {
        //brick.y=brick.y+1;
        brick.fall_brick_down();
    }
    
    public void left()
    {
        
        if(brick.check_collision_left()==false)
        {
            brick.x=brick.x-1;
        }
    }
    
    public void right()
    {
         if(brick.check_collision_right()==false)
        {
            brick.x=brick.x+1;
        }
        
    }
    
    public void run() {
       while(true){
        try
        {
            a++;
            
            int speed=20;
            if(level==1) speed=20;
            if(level==2) speed=18;
            if(level==3) speed=16;
            if(level==4) speed=14;
            if(level==5) speed=12;
            if(level==6) speed=10;
            if(level==7) speed=8;
            if(level==8) speed=6;
            if(level==9) speed=5;
            if(level==10) speed=4;
            
            
            if(a>=speed){
            a=0;
            brick.fall_brick_down();
            }
            
            this.repaint();    
            
            Thread.sleep(25);
            
        } catch(Exception exc){};
        
       }
    }


    public void keyTyped(KeyEvent ke) {
        
    }


    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==87){rotate();}
        if(e.getKeyCode()==83){down();}
        if(e.getKeyCode()==65){left();}
        if(e.getKeyCode()==68){right();}
        
    }


    public void keyReleased(KeyEvent ke) {

    }
    
}
