/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tetris;

import java.util.Random;


public class Brick {

    
Random rnd=new Random();

int x=2;
int y=0;


int rot=1;
String brick_type;

public int[][] brick_table=new int[4][4];

public int[][] brick_s_r1=new int[3][3];
public int[][] brick_s_r2=new int[3][3];

public int[][] brick_rs_r1=new int[3][3];
public int[][] brick_rs_r2=new int[3][3];

public int[][] brick_l_r1=new int[3][3];
public int[][] brick_l_r2=new int[3][3];
public int[][] brick_l_r3=new int[3][3];
public int[][] brick_l_r4=new int[3][3];

public int[][] brick_rl_r1=new int[3][3];
public int[][] brick_rl_r2=new int[3][3];
public int[][] brick_rl_r3=new int[3][3];
public int[][] brick_rl_r4=new int[3][3];

public int[][] brick_b=new int[3][3];

public int[][] brick_t_1=new int[3][3];
public int[][] brick_t_2=new int[3][3];
public int[][] brick_t_3=new int[3][3];
public int[][] brick_t_4=new int[3][3];

public int[][] brick_i_1=new int[4][4];
public int[][] brick_i_2=new int[4][4];

int next=0;

public void setBrick(String type)
{
    this.brick_type=type;
};

public boolean check_collision_rotate()
{
    Brick b=new Brick(this.brick_type);
    b.x=this.x;
    b.y=this.y;
    
    b.rot=this.rot+1;
    if(b.rot==5) b.rot=1;
    
    b.getBrick();
    
        if(this.brick_type.equals("I")){
                    for(int y2=0;y2<4;y2++)
                    {
                            for(int x2=0;x2<4;x2++)
                            {
                                if(b.brick_table[y2][x2]==1){
                                    //Tetris.bricks_table[y+y2][x+x2]=brick_table[y2][x2];
                                    if(Tetris.bricks_table[y+y2][x+x2]==1) return true;
                                }
                            }
                    }
                }else
                {
                    for(int y2=0;y2<3;y2++)
                    {
                            for(int x2=0;x2<3;x2++)
                            {
                                if(b.brick_table[y2][x2]==1){
                                    //Tetris.bricks_table[y+y2][x+x2]=brick_table[y2][x2];
                                    if(Tetris.bricks_table[y+y2][x+x2]==1) return true;
                                }
                            }
                    }
                }
    
    
    
    return false;
}

public boolean check_collision_right()
{
    
                if(this.brick_type.equals("I")){
                    for(int y2=0;y2<4;y2++)
                    {
                            for(int x2=0;x2<4;x2++)
                            {
                                if(brick_table[y2][x2]==1){
                                    //Tetris.bricks_table[y+y2][x+x2]=brick_table[y2][x2];
                                    if(Tetris.bricks_table[y+y2][x+x2+1]==1) return true;
                                }
                            }
                    }
                }else
                {
                    for(int y2=0;y2<3;y2++)
                    {
                            for(int x2=0;x2<3;x2++)
                            {
                                if(brick_table[y2][x2]==1){
                                    //Tetris.bricks_table[y+y2][x+x2]=brick_table[y2][x2];
                                    if(Tetris.bricks_table[y+y2][x+x2+1]==1) return true;
                                }
                            }
                    }
                }
    
    
    
    return false;
}


public boolean check_collision_left()
{
    if(x==0) return true;
                if(this.brick_type.equals("I")){
                    for(int y2=0;y2<4;y2++)
                    {
                            for(int x2=0;x2<4;x2++)
                            {
                                if(brick_table[y2][x2]==1){
                                    //Tetris.bricks_table[y+y2][x+x2]=brick_table[y2][x2];
                                    if(Tetris.bricks_table[y+y2][x+x2-1]==1) return true;
                                }
                            }
                    }
                }else
                {
                    for(int y2=0;y2<3;y2++)
                    {
                            for(int x2=0;x2<3;x2++)
                            {
                                if(brick_table[y2][x2]==1){
                                    //Tetris.bricks_table[y+y2][x+x2]=brick_table[y2][x2];
                                    if(Tetris.bricks_table[y+y2][x+x2-1]==1) return true;
                                }
                            }
                    }
                }
    
    
    
    return false;
}

public boolean check_collision_down()
{
                if(this.brick_type.equals("I")){
                    for(int y2=0;y2<4;y2++)
                    {
                            for(int x2=0;x2<4;x2++)
                            {
                                if(brick_table[y2][x2]==1){
                                    //Tetris.bricks_table[y+y2][x+x2]=brick_table[y2][x2];
                                    if(Tetris.bricks_table[y+y2+1][x+x2]==1) return true;
                                }
                            }
                    }
                }else
                {
                    for(int y2=0;y2<3;y2++)
                    {
                            for(int x2=0;x2<3;x2++)
                            {
                                if(brick_table[y2][x2]==1){
                                    //Tetris.bricks_table[y+y2][x+x2]=brick_table[y2][x2];
                                    if(Tetris.bricks_table[y+y2+1][x+x2]==1) return true;
                                }
                            }
                    }
                }
    
    
    
    return false;
}

public void fall_brick_down()
{


        
        if(check_collision_down()){
                   lockBrick();
                   return;
        }
        this.y=y+1;
}

public void lockBrick()
{
                    if(this.brick_type.equals("I")){
                        for(int y2=0;y2<4;y2++)
                        {
                                for(int x2=0;x2<4;x2++)
                                {
                                    if(brick_table[y2][x2]==1){
                                        Tetris.bricks_table[y+y2][x+x2]=brick_table[y2][x2];
                                    }
                                }
                        }
                    }else
                    {
                        for(int y2=0;y2<3;y2++)
                        {
                                for(int x2=0;x2<3;x2++)
                                {
                                    if(brick_table[y2][x2]==1){
                                        Tetris.bricks_table[y+y2][x+x2]=brick_table[y2][x2];
                                    }
                                }
                        }
                    }
                    getNewBrick();y=0;x=5;
}

public void getNewBrick()
{
rnd=new Random();
this.rnd.setSeed(System.currentTimeMillis());

int r=next;

next=rnd.nextInt(7);

if(r==0) this.setBrick("L");
if(r==1) this.setBrick("RL");
if(r==2) this.setBrick("S");
if(r==3) this.setBrick("RS");
if(r==4) this.setBrick("T");
if(r==5) this.setBrick("I");
if(r==6) this.setBrick("B");

    
}

public void getBrick()
{

    for(int y=0;y<4;y++)
        {
            for(int x=0;x<4;x++)
            {
                brick_table[y][x]=0;
            }
        }
    
    if(this.brick_type.equals("L"))
    {
        for(int y=0;y<3;y++)
        {
            for(int x=0;x<3;x++)
            {
                if(this.rot==1){brick_table[y][x]=brick_l_r1[y][x];}
                if(this.rot==2){brick_table[y][x]=brick_l_r2[y][x];}
                if(this.rot==3){brick_table[y][x]=brick_l_r3[y][x];}
                if(this.rot==4){brick_table[y][x]=brick_l_r4[y][x];}
            }
        }
    }
    
    if(this.brick_type.equals("RL"))
    {
        for(int y=0;y<3;y++)
        {
            for(int x=0;x<3;x++)
            {
                if(this.rot==1){brick_table[y][x]=brick_rl_r1[y][x];}
                if(this.rot==2){brick_table[y][x]=brick_rl_r2[y][x];}
                if(this.rot==3){brick_table[y][x]=brick_rl_r3[y][x];}
                if(this.rot==4){brick_table[y][x]=brick_rl_r4[y][x];}
            }
        }
    }
    
    if(this.brick_type.equals("S"))
    {
        for(int y=0;y<3;y++)
        {
            for(int x=0;x<3;x++)
            {
                if(this.rot==1){brick_table[y][x]=brick_s_r1[y][x];}
                if(this.rot==2){brick_table[y][x]=brick_s_r2[y][x];}
                if(this.rot==3){brick_table[y][x]=brick_s_r1[y][x];}
                if(this.rot==4){brick_table[y][x]=brick_s_r2[y][x];}
            }
        }
    }
    
    if(this.brick_type.equals("RS"))
    {
        for(int y=0;y<3;y++)
        {
            for(int x=0;x<3;x++)
            {
                if(this.rot==1){brick_table[y][x]=brick_rs_r1[y][x];}
                if(this.rot==2){brick_table[y][x]=brick_rs_r2[y][x];}
                if(this.rot==3){brick_table[y][x]=brick_rs_r1[y][x];}
                if(this.rot==4){brick_table[y][x]=brick_rs_r2[y][x];}
            }
        }
    }
    
    if(this.brick_type.equals("T"))
    {
        for(int y=0;y<3;y++)
        {
            for(int x=0;x<3;x++)
            {
                if(this.rot==1){brick_table[y][x]=brick_t_1[y][x];}
                if(this.rot==2){brick_table[y][x]=brick_t_2[y][x];}
                if(this.rot==3){brick_table[y][x]=brick_t_3[y][x];}
                if(this.rot==4){brick_table[y][x]=brick_t_4[y][x];}
            }
        }
    }
    
    if(this.brick_type.equals("B"))
    {
        for(int y=0;y<3;y++)
        {
            for(int x=0;x<3;x++)
            {
                if(this.rot==1){brick_table[y][x]=brick_b[y][x];}
                if(this.rot==2){brick_table[y][x]=brick_b[y][x];}
                if(this.rot==3){brick_table[y][x]=brick_b[y][x];}
                if(this.rot==4){brick_table[y][x]=brick_b[y][x];}
            }
        }
    }
    
    
    if(this.brick_type.equals("I"))
    {
        for(int y=0;y<4;y++)
        {
            for(int x=0;x<4;x++)
            {
                if(this.rot==1){brick_table[y][x]=brick_i_1[y][x];}
                if(this.rot==2){brick_table[y][x]=brick_i_2[y][x];}
                if(this.rot==3){brick_table[y][x]=brick_i_1[y][x];}
                if(this.rot==4){brick_table[y][x]=brick_i_2[y][x];}
            }
        }
    }
    
    
}

public Brick(String name)
{
    next=rnd.nextInt(7);
    
    getNewBrick();
    
    this.brick_type=name;
    
    this.rnd.setSeed(System.currentTimeMillis());
    
    brick_table=new int[][]
        {
            {0,0,0,0},
            {0,0,0,0},
            {0,0,0,0},
            {0,0,0,0}
        };
    
    brick_i_1=new int[][]
        {
            {1,0,0,0},
            {1,0,0,0},
            {1,0,0,0},
            {1,0,0,0}
        };
    
    brick_i_2=new int[][]
        {
            {0,0,0,0},
            {1,1,1,1},
            {0,0,0,0},
            {0,0,0,0}
        };
    
    brick_t_1=new int[][]
        {
            {0,0,0},
            {0,1,0},
            {1,1,1}
        };
    
    brick_t_2=new int[][]
        {
            {1,0,0},
            {1,1,0},
            {1,0,0}
        };
    
    brick_t_3=new int[][]
        {
            {1,1,1},
            {0,1,0},
            {0,0,0}
        };
    
    brick_t_4=new int[][]
        {
            {0,1,0},
            {1,1,0},
            {0,1,0}
        };
    
    brick_b=new int[][]
        {
            {0,0,0},
            {1,1,0},
            {1,1,0}
        };
    
    brick_s_r1=new int[][]
        {
            {0,1,1},
            {1,1,0},
            {0,0,0}
        };
    
    brick_s_r2=new int[][]
        {
            {1,0,0},
            {1,1,0},
            {0,1,0}
        };
    
    brick_rs_r1=new int[][]
        {
            {1,1,0},
            {0,1,1},
            {0,0,0}
        };
    
    brick_rs_r2=new int[][]
        {
            {0,1,0},
            {1,1,0},
            {1,0,0}
        };
    
    brick_l_r1=new int[][]
        {
            {1,0,0},
            {1,0,0},
            {1,1,0}
        };
    
    brick_l_r2=new int[][]
        {
            {1,1,1},
            {1,0,0},
            {0,0,0}
        };
    
    brick_l_r3=new int[][]
        {
            {1,1,0},
            {0,1,0},
            {0,1,0}
        };
    
    brick_l_r4=new int[][]
        {
            {0,0,0},
            {0,0,1},
            {1,1,1}
        };
    
    
    
    brick_rl_r1=new int[][]
        {
            {0,1,0},
            {0,1,0},
            {1,1,0}
        };
    
    brick_rl_r2=new int[][]
        {
            {0,0,0},
            {1,0,0},
            {1,1,1}
        };
    
    brick_rl_r3=new int[][]
        {
            {1,1,0},
            {1,0,0},
            {1,0,0}
        };
    
    brick_rl_r4=new int[][]
        {
            {1,1,1},
            {0,0,1},
            {0,0,0}
        };
}


}
